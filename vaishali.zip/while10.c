#include<stdio.h>

int main()
{
   int a=0;
  int i=1;
  
  while(i<=10)
  {
	  {
		  a=a+i;
	  }
	  printf("%d\t",a);
	  i++;
  }

}