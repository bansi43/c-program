#include<stdio.h>
void sum()
{
    int p,r,n;
	int intrest;
	printf("enter the p:\n");
	scanf("%d",&p);
	
	printf("enter the r:\n");
	scanf("%d",&r);
	
	printf("enter the n:\n");
	scanf("%d",&n);
	
	intrest=(p*r*n)/100;
	printf("the simple intrest is:%d",intrest)
	

}