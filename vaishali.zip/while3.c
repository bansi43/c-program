#include<stdio.h>

int main()
{
   int i=51;
   
   while(i<=99)
   {
	   printf("%d\t",i);
	      i++;
   }
   
   return 0;


}
