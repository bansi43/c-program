#include<stdio.h>
int main()
{
    int i;
	int sum=0;
	
	

	
	for(i=1;i<=50;i++)
	{

	if(i%2!=0)                                   0)
	{
		//sum+=i;
		printf("%d\t",i);
	}
	}
	
	//printf(" odd sum %d",sum);
	
	
    return 0;
}