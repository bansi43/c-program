/*#include<stdio.h>
int sum(int p,int r, int n)
{
   int intrest=(p*r*n)/100;
   return intrest;

}
int main()
{
  int intrest=sum(50,100,300);
  printf("the simple intrest is:%d",intrest);

}*/

#include<stdio.h>
void sum(50*10*100)
{
	  int intrest=sum(50,100,300);
   int intrest=(p*r*n)/100;
  
  printf("the simple intrest is:%d",intrest);


}

int main()
{

	sum();
}