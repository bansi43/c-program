#include <stdio.h>
int main()

{
  int a=7;
  
  printf("%d\n",a--);
  printf("%d\n",a--);
  printf("%d\n",--a);
  printf("%d\n",--a);
  printf("%d\n",a--);
  printf("%d\n",--a);
  printf("%d\n",--a);
  printf("%d\n",a--);
  printf("%d\n",--a);
  printf("%d\n",a--);
 

 return 0;

}