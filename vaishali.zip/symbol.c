#include<stdio.h>

int main()
{
	int a=10;
	char symbol='A';
	
	printf("%d", symbol);
	
	return 0;
	
}	
	