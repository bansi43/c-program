#include<stdio.h>
#include<string.h>

struct student
{
   int id;
   char name[50];
   int marks;
  
};

struct student std10,std11,std12;
