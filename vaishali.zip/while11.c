#include<stdio.h>

int main()
{
	
	int i; 
	char 'A'=65;
	
	while('Z'<=90)
	{
		printf("%c -> %d /n",i,i);
		i++;
	}
	
	
}