#include<stdio.h>

int main()

{
 
  int n;
 
  
   
    char i='A';
   while(i<='Z')
   {
	   printf("%c\t",i);
	   i++;
   }
    
   return 0;
}