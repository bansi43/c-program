#include<stdio.h>

void sum()
{

   int a=10;
   int b=20;
   
   printf("total=%d",a+b);
}
int main()
{
  sum(); //call
 
}