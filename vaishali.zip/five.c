#include<stdio.h>
int main()
{
    int i;
	
	for(i=51;i<=99;i++)
	{
	  printf("%d\t",i);

	}

    return 0;
}