#include<iostream>
using namespace std;

int main()
{
   int n;

   cout<<"enter a number:";
   cin>>n;

   if(n>=0)
   {
    cout<<"is a positive"<<n;
   }

   else{
    cout<<"is a nagative"<<n;
   }
 


}