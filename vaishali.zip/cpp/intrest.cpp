#include<iostream>
using namespace std;

int main()
{
   int p,r,n,intrest;

   cout<<"enter the p:";
   cin>>p;

   cout<<"enter the r:";
   cin>>r;

   cout<<"enter the n:";
   cin>>n;

   intrest=p*r*n/100;

   cout<<"the simple intrest:"<<intrest;


}