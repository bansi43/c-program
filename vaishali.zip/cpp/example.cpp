#include<iostream>
using namespace std;

int main()
{

  int a;
  cout<<"enter the value:";
  cin>>a;

  cout<<"the value is:"<<a<<endl;
  cout<<"the value is:"<<a;

  return 0;

}