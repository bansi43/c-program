#include<iostream>
using namespace std;

void convert (double doller,int rupee)
{
    cout<<"enter the dolller:"
    cin>>doller;
    cout<<doller*rupee;
}
void convert(int feat,int inches)
{
     cout<<"enter the inches:"
    cin>>inches;
    cout<<feat*inches;
}
 void convert (int inches,double cm,)
{
    cout<<"enter the cm:"
    cin>>cm;
    cout<<inches*cm;
}