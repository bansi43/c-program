#include<iostream>
#include<fstream>//library
using namespace std;
int main()
{
   string st="skill";
   string st2;
   ofstream out("semple.txt");
   out<<st;

   
    //ifstream in("semple.txt");
   // getline(in,st2);
   // cout<<st2;
   // getline(in,st2);
   //cout<<st2;
    return 0;
   

}