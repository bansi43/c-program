#include<iostream>
using namespace std;

int main()
{
     int radius;
     float pi=3.14;
     float area;

     cout<<"enter the value of circle:";
     cin>>radius;
     
     area=pi*radius*radius;

     cout<<"the area is:"<<area;

     
}