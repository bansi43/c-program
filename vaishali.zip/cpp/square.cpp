#include<iostream>
using namespace std;

int main()
{
  int side,area;

  cout<<"enter the area of circle:";
  cin>>side;

  area=side*side;

  cout<<"area of square:"<<area;

}