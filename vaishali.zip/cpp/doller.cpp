#include<iostream>
using namespace std;

int main()
{

    int doller;
    float rupee;
    float total=0;
    cout<<"enter the doller:";
     cin>>doller;
    cout<<"enter the rupee:";
    cin>>rupee;

    total=rupee*doller;
    cout<<"total  rupee: "<<total;


}