#include<iostream>
using namespace std;

int main()
{
  int base,height,area;

  cout<<"enter the base:";
  cin>>base;

  cout<<"enter the height:";
  cin>>height;

  area=base*height/2;

  cout<<" traingle : "<<area;



}
