#include<iostream>
using namespace std;

int main()
{
    int width,height,area;

    cout<<"enter the height:";
    cin>>height;

    cout<<"enter thr width:";
    cin>>width;

      area=height*width;
      cout<<"enter the rectangle:"<<area;

}