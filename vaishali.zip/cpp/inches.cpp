#include<iostream>
using namespace std;

int main()
{
  int inches;
  float cm,total;



   cout<<"entrer the inch:";
   cin>>inches;

   cout<<"enter the cm:";
   cin>>cm;

  total=inches*cm;
  
  cout<<"total length in inches:"<<total;
  


}
