#include<stdio.h>

int main()

{
  int num;
  
	
	printf("enter a number");
	scanf("%d",&num);
	
	if(num>=0)
	{
		printf(" %d is positive:\n");
	}
	else if(num>=0)
	{
		printf("%d is nagative:\n");
	}	
	else
	{
		printf("%d is zero:\n");
	}	
	 
	 return 0;
	
}