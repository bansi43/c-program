#include<stdio.h>

int main()

{
 
  int n;
 
    
   printf("enter the number");
   scanf("%d",&n);
   
   
    int i=n;
   while(i>=1)
   {
	   printf("%d\t",i);
	   i--;
   }
    
   
}