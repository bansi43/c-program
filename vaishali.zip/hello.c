#include<stdio.h>

int main()
{
  printf("hello word");

  return 0;
}