#include<stdio.h>
int main()
{
	
	
	int arr[4]={1,2,3,4};
	int a=0;
	int b=0;
	
	for(int i=0;i<4;i++)
	{
		if(arr[i]%2==0)
		{
			a=a+arr[4];
		}
		else
		{
			a=a+arr[4];
		}
	}
	printf("even sum number:",a);
	printf("odd sum number:",b);
}